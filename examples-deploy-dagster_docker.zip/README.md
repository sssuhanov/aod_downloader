View this example in the Dagster docs at https://docs.dagster.io/examples/deploy_docker.
